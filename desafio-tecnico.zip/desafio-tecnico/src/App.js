import React from "react";
import JuegoContador from "./Juegocontador";

function App() {
  return (
    <div>
      <JuegoContador />
    </div>
  );
}

export default App;
